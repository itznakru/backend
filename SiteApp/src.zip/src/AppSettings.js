const appSettings={
    REST_SERVERURL:"http://localhost:5141/api/",
    ERROR_PAGE:"/error"
}
export {appSettings}